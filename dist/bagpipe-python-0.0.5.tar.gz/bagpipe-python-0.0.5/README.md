# BagPipe

Bagpipe is a scikit-learn powered preprocessing library for listed dataframes based on the pipline structure of sklearn. It provides a set of specialized new transformers which can be used in addition to exsisting sklearn transformers, making it easier for handling datasets containing different csv in a sequence based setting.
